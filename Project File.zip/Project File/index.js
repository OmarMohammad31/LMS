const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const authRoutes = require('./routes/auth');
const sessionRoutes = require("./routes/session");
dotenv.config();

const app = express();
app.use(express.json());
app.use('/api/auth', authRoutes);
app.use("/api/sessions", sessionRoutes);
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log('mongodb connected'))
    .catch((err) => console.log('mongodb connection error:', err));

const port = process.env.PORT || 3000;
app.listen(port, () =>
    console.log(`server running on port ${port}`));