const express = require('express');
const router = express.Router();
const { requireAuth, requireInstructor } = require('../middleware/auth');
const { register, login, logout } = require('../controllers/auth');
router.post('/register', register);
router.post('/login', login);
router.post('/logout', requireAuth, logout);
module.exports = router;