const express = require("express");
const router = express.Router();
const { createSession , getSessions, bookSession, getSessionRoster} = require("../controllers/session");
const { requireAuth, requireInstructor} = require("../middleware/auth");
router.post("/", requireAuth, requireInstructor, createSession);
router.get("/", requireAuth, getSessions);
router.post("/:id/book", requireAuth, bookSession);
router.get("/:id/roster", requireAuth, getSessionRoster);

module.exports = router;