const Session = require("../models/Session");
const createSession = async (req, res) => {
  try {
    const { title, description, startTime, duration, capacity } = req.body;
    const newSession = new Session({
      title,
      description,
      startTime,
      duration,
      capacity,
      instructor: req.user.id
    });
    await newSession.save();
    res.status(201).json({ message: "session created successfully", session: newSession });
  } catch (error) {
    res.status(500).json({ message: "server error", error: error.message });
  }
};
const getSessions = async (req, res) => {
  try {
    const sessions = await Session.find();
    res.status(200).json(sessions);
  } catch (error) {
    res.status(500).json({ message: "server error", error: error.message });
  }
};
const bookSession = async (req, res) => {
  try {
    const session = await Session.findById(req.params.id);
    if (!session) {
      return res.status(404).json({ message: "session not found" });
    }
    if (session.attendees.includes(req.user.id)) {
      return res.status(400).json({ message: "you already booked this session" });
    }
    if (session.attendees.length >= session.capacity) {
      return res.status(400).json({ message: "session is full" });
    }
    session.attendees.push(req.user.id);
    await session.save();
    res.status(200).json({ message: "booked successfully", session });
  } catch (error) {
    res.status(500).json({ message: "server error", error: error.message });
  }
};
const getSessionRoster = async (req, res) => {
  try {
    const session = await Session.findById(req.params.id).populate("attendees", "name email");
    if (!session) {
      return res.status(404).json({ message: "session not found" });
    }
    if (session.instructor.toString() !== req.user.id) {
      return res.status(403).json({ message: "not your session" });
    }
    res.status(200).json({ attendees: session.attendees });
  } catch (error) {
    res.status(500).json({ message: "server error", error: error.message });
  }
};

module.exports = { createSession, getSessions, bookSession, getSessionRoster };
