const bcrypt = require('bcryptjs');
const User = require('../models/User');

const register = async (req, res) => {
  try {
    const { name, email, password, isInstructor } = req.body;

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'email already registered' });
    }
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    const newUser = new User({
      name,email,password: hashedPassword,
      isInstructor: isInstructor || false
    });
    await newUser.save();
  res.status(201).json({ message: 'user registered successfully' });
  } catch (error) {
    res.status(500).json({ message: 'server error', error: error.message });
  }};

const jwt = require('jsonwebtoken');
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'invalid email or password' });
    }
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'invalid email or password' });
    }
    const token = jwt.sign(
      { id: user._id, isInstructor: user.isInstructor },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    res.status(200).json({ token });
  } catch (error) {
    res.status(500).json({ message: 'server error', error: error.message });}
};
const logout = (req, res) => {
  res.status(200).json({ message: 'logged out successfully' });
};
module.exports = { register, login, logout };

